# AgentRisk Python SDK

Official Python client for [AgentRisk](https://agentrisk.dev) — pre-trade token risk scoring for Base Network, paid per call via the x402 protocol.

## Installation

```bash
pip install agentrisk
```

## Usage

```python
import asyncio
from agentrisk import AgentRisk

async def main():
    risk = AgentRisk(private_key="your_base_wallet_private_key")
    result = await risk.scan("0xTokenAddressHere")
    print(result["verdict"])
    print("Risk score:", result["risk_score"], "/", result["risk_level"])
    print("Safe to trade:", result["risk_score"] <= 45)

asyncio.run(main())
```

## What it checks

- Honeypot detection
- Deployer wallet freshness
- Brand impersonation
- LP lock status (cross-verified on-chain)
- Ownership renouncement, mint/pause functions
- Holder concentration

## Requirements

Your wallet needs a small amount of USDC (0.15 per scan) and ETH (for gas) on Base.

## Links

- [Documentation](https://github.com/Neurobyteio/agentrisk)
- [Live API](https://agentrisk.dev)
